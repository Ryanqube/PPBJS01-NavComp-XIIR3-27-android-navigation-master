# Navigation Architecture
Android development tool - Navigation Architecture Component

In Google I/O 2018, they announced the new modern Navigation Architecture Component. Its bundled in Android Jetpack's Architecture section.

Please check the below post for more detailed about Navigation architecture component.


1. [Android Navigation Architecture Component — Part 1][PART1]

2. [Android Navigation Architecture Component — Part 2][PART2]

3. [Android Navigation Architecture Component - Part 3][PART3]







[PART1]: https://medium.com/@shanmugasanthosh/android-navigation-architecture-component-part-1-3c6458e9bff3
[PART2]: https://medium.com/@shanmugasanthosh/android-navigation-architecture-component-part-2-87352a3f86fb
[PART3]: https://medium.com/@shanmugasanthosh/android-navigation-architecture-component-part-3-f9cb9e9b642e
